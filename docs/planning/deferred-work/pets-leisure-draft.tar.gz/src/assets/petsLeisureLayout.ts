export const petsLeisureArtIds = ['dog', 'cat', 'rabbit', 'parrot', 'paw', 'food', 'play', 'vet', 'guitar', 'painting', 'photography', 'chess', 'cinema', 'concert', 'museum', 'nightclub'] as const;
export type PetsLeisureArtId = typeof petsLeisureArtIds[number];
export const petsLeisureAtlasSize = [1448, 1086] as const;
const columns = [[8, 366], [386, 332], [744, 340], [1112, 330]] as const;
const rows = [[0, 286], [294, 232], [534, 258], [800, 264]] as const;
export function petsLeisureRect(id: PetsLeisureArtId): readonly [number, number, number, number] {
  const index = petsLeisureArtIds.indexOf(id), [x, width] = columns[index % 4], [y, height] = rows[Math.floor(index / 4)];
  return [x, y, width, height];
}
