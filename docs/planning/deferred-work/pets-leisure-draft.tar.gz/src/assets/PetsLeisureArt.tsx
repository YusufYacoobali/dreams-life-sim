import React from 'react';
import { Image, View } from 'react-native';
import { petsLeisureAtlasSize, PetsLeisureArtId, petsLeisureRect } from './petsLeisureLayout';
const atlas = require('../../assets/generated/pets-leisure-atlas.png');
export function PetsLeisureArt({ id, width = 72 }: { id: PetsLeisureArtId; width?: number }) {
  const [x, y, sourceWidth, sourceHeight] = petsLeisureRect(id), scale = width / sourceWidth;
  return <View accessibilityElementsHidden importantForAccessibility="no-hide-descendants" style={{ width, height: sourceHeight * scale, overflow: 'hidden', borderRadius: 8 }}><Image accessible={false} source={atlas} resizeMode="stretch" style={{ position: 'absolute', width: petsLeisureAtlasSize[0] * scale, height: petsLeisureAtlasSize[1] * scale, left: -x * scale, top: -y * scale }} /></View>;
}
